<div class="thrv_wrapper thrv_toggle_shortcode <?php echo $_POST['colour']; ?>">
	<div class="tve_faq">
		<div class="tve_faqI">
			<div class="tve_faqB"><span class="tve_not_editable tve_toggle"></span><h4>Content Toggle Headline</h4></div>
			<div class="tve_faqC" style="display: none;"><p>Add your content here...</p></div>
		</div>
	</div>
</div>