<div class="thrv_wrapper">
	<hr class="tve_sep tve_sep1"/>
</div>