<?php /*
 <div class="thrv_wrapper thrv_columns tve_clearfix">
    <div class="tve_colm tve_foc"><p>Column 1</p></div>
    <div class="tve_colm tve_tfo tve_lst"><p>Column 2</p></div>
</div>
 */ ?>
<div class="thrv_wrapper thrv_columns tve_clearfix">
	<div class="tve_colm tve_foc tve_df tve_ofo "><p>Column 1</p></div>
	<div class="tve_colm tve_tfo tve_df tve_lst"><p>Column 2</p></div>
</div>