<div class="thrv_wrapper thrv_testimonial_shortcode" data-tve-style="3">
	<div class="tve_ts tve_ts3 <?php echo $_POST['colour']; ?>">
		<div class="tve_ts_o">
			<img class="tve_image" src="<?php echo $_POST['cssdir']; ?>/images/photo1.jpg" alt=""/>
                <span>
                    <b>John Doe</b>
                    UI/UX Designer
                </span>
		</div>
		<div class="tve_ts_cn">
			<span class="tve_ts_ql"></span>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et
				dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip
				ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu
				fugiat nulla pariatur.</p>
			<span class="tve_ts_qr"></span>
		</div>
	</div>
</div>