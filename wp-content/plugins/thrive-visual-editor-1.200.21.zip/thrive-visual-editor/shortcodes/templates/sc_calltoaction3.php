<div class="thrv_wrapper thrv_calltoaction_shortcode" data-tve-style="3">
	<div class="tve_ca tve_ca3 <?php echo $_POST['colour']; ?>">
		<div class="tve_ca_o">
			<h1>LOREM IPSUM DOLOR SIT AMET ELIT</h1>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et.</p>
		</div>
		<div class="tve_ca_t">
			<div class="tve_btn tve_btn2 <?php echo $_POST['colour']; ?> tve_normalBtn">
				<a class="tve_btnLink" href="">
					<span>Buy it Now!</span>
					<span class="tve_ca_sp">lorem ipsum dolor</span>
				</a>
			</div>
		</div>
		<div class="tve_corner"></div>
		<div class="tve_clear"></div>
	</div>
</div>