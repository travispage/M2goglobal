<div class="thrv_wrapper thrv_bullets_shortcode">
	<ul class="tve_ul tve_ul3 <?php echo $_POST['colour']; ?>">
		<li>Bullet Point 1</li>
		<li>Bullet Point 2</li>
	</ul>
</div>