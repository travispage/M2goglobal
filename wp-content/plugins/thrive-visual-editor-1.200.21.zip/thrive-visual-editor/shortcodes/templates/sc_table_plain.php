<div class="table_placeholder thrv_wrapper thrv_table">
	<a class="tve_click tve_lb_small tve_green_button clearfix" id="lb_table" data-ctrl="controls.lb_open">
		<input type="hidden" name="table_style" value="plain">
		<i class="tve_icm tve-ic-table"></i>
		<span>Add Table</span>
	</a>
</div>

