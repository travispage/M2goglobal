<div class="thrv_wrapper thrv_columns">
	<div class="tve_colm tve_twc"><p>Column 1</p></div>
	<div class="tve_colm tve_twc tve_lst"><p>Column 2</p></div>
</div>
