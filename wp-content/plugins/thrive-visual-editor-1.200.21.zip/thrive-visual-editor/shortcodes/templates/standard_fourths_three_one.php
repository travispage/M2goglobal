<?php /*
 <div class="thrv_wrapper thrv_columns tve_clearfix">
    <div class="tve_colm tve_tfo"><p>Column 1</p></div>
    <div class="tve_colm  tve_foc tve_lst"><p>Column 2</p></div>
</div>
 */ ?>
<div class="thrv_wrapper thrv_columns tve_clearfix">
	<div class="tve_colm tve_tfo tve_df "><p>Column 1</p></div>
	<div class="tve_colm  tve_foc tve_ofo tve_df tve_lst"><p>Column 2</p></div>
</div>