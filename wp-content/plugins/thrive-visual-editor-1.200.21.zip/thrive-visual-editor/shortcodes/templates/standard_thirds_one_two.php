<div class="thrv_wrapper thrv_columns tve_clearfix">
	<div class="tve_colm tve_oth"><p>Column 1</p></div>
	<div class="tve_colm tve_tth tve_lst"><p>Column 2</p></div>
</div>