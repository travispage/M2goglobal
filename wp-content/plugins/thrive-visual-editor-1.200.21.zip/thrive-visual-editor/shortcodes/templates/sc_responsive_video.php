<div class="responsive_video_placeholder thrv_responsive_video thrv_wrapper">
	<a class="tve_green_button clearfix" href="#" target="_self">
		<i class="tve_icm tve-ic-upload"></i>
		<span>Add Video</span>
	</a>
	<div class="tve_responsive_video_container" style="display: none">
		<div class="video_overlay"></div>
		<iframe src="" frameborder="0" allowfullscreen></iframe>
	</div>
</div>