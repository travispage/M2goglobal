<?php

/**
 * Created by PhpStorm.
 * User: radu
 * Date: 18.11.2014
 * Time: 12:41
 */
class TCB_Custom_Menu_Walker extends Walker_Nav_Menu {

} 