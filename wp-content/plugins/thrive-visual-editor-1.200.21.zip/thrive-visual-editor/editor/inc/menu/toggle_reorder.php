<div class="tve_ed_btn tve_btn_text tve_click" data-ctrl="controls.click.reorder_toggle_done">
	<div class="tve_icm tve-ic-checkmark tve_left" style="color: #47bb28"></div>
	<?php echo __( "Done", "thrive-cb" ) ?>
</div>