<span class="tve_options_headline"><span class="tve_icm tve-ic-move"></span><?php echo __( 'Thrive Ultimatum Countdown Menu', 'thrive-cb' ) ?></span>
<ul class="tve_menu">
	<li data-lb="lb_ultimatum_shortcode" class="tve_ed_btn tve_btn_text tve_click" data-ctrl="controls.lb_open">
		<?php echo __( 'Change Countdown', "thrive-cb" ) ?>
	</li>
	<li class="tve_ed_btn tve_btn_text">
		<a id="tve_ult_edit_shortcode" class="tve_btn_text" style="color: #626262" target="_blank" href="javascript:void(0)"><?php echo __( 'Edit Countdown in Ultimatum' ) ?></a>
	</li>
</ul>