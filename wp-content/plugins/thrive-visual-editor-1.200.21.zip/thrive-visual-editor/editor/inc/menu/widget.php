<span class="tve_options_headline"><span class="tve_icm tve-ic-move"></span><?php echo __( "Widget options", "thrive-cb" ) ?></span>
<ul class="tve_menu">
	<li id="lb_widgets" class="tve_ed_btn tve_btn tve_btn_text tve_click" data-ctrl="controls.lb_open"><?php echo __( "Edit Widget options", "thrive-cb" ) ?></li>
	<?php include dirname( __FILE__ ) . '/_margin.php' ?>
</ul>