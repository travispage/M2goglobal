<span class="tve_options_headline"><span class="tve_icm tve-ic-move"></span><?php echo __( "Content Toggle options", "thrive-cb" ) ?></span>
<ul class="tve_menu">
	<?php include dirname( __FILE__ ) . '/_custom_colors.php' ?>
	<li class="tve_add_highlight">
		<div class="tve_ed_btn tve_btn_text tve_center tve_left tve_click" data-ctrl="controls.click.add_toggle"><?php echo __( "Add New Toggle", "thrive-cb" ) ?></div>
	</li>
	<?php include dirname( __FILE__ ) . '/_margin.php' ?>
	<li class="">
		<div class="tve_ed_btn tve_btn_text tve_center tve_left tve_click" data-ctrl="controls.click.reorder_toggle"><?php echo __( "Reorder Toggles", "thrive-cb" ) ?></div>
	</li>
</ul>

