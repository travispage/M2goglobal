<span class="tve_options_headline"><span class="tve_icm tve-ic-move"></span><?php echo __( "Custom HTML options", "thrive-cb" ) ?></span>
<ul class="tve_menu">
	<li id="lb_custom_html" class="tve_ed_btn tve_btn_text tve_click" data-ctrl="controls.lb_open" data-multiple-hide><?php echo __( "Edit Custom HTML Code", "thrive-cb" ) ?>
	</li>
	<?php include dirname( __FILE__ ) . '/_margin.php' ?>
</ul>