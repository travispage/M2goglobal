<span class="tve_options_headline"><span class="tve_icm tve-ic-move"></span><?php echo __( "List options", "thrive-cb" ) ?></span>
<ul class="tve_menu">
	<?php include dirname( __FILE__ ) . '/_margin.php' ?>
	<?php include dirname( __FILE__ ) . '/_line_height.php' ?>
</ul>