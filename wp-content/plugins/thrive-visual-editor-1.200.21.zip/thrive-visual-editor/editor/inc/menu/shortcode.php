<span class="tve_options_headline"><span class="tve_icm tve-ic-move"></span><?php echo __( "WordPress Content options", "thrive-cb" ) ?></span>
<ul class="tve_menu">
	<?php include dirname( __FILE__ ) . '/_margin.php' ?>
	<li class="tve_ed_btn tve_btn_text tve_click" id="tve_shortcode_edit" data-multiple-hide><?php echo __( "Edit Shortcode", "thrive-cb" ) ?></li>
</ul>